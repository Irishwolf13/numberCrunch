# @blackcat/auth

Web API authentication for Black Cat Matrix's Keycloak realm. The main entrypoint and storage adapters are server-only; `@blackcat/auth/browser` is a separate browser helper. The main entrypoint and D1 adapter use no Node APIs. PostgreSQL clients are injected through a structural query interface; the package never opens its own database connection.

```ts
import { createAuth } from '@blackcat/auth';
import { createPostgresAuthStore } from '@blackcat/auth/postgres';
// Worker alternative: import { createD1AuthStore } from '@blackcat/auth/d1';
const auth = createAuth({
  issuer: env.OIDC_ISSUER,
  clientId: env.OIDC_CLIENT_ID,
  clientSecret: env.OIDC_CLIENT_SECRET,
  origin: env.APP_ORIGIN,
  encryptionKey: env.AUTH_ENCRYPTION_KEY,
  store: createPostgresAuthStore(pool),
  onLogout: async ({ sid, sub }) => { /* close matching trusted sockets */ },
});
const handled = await auth.handle(request); // Response or null for unrelated paths
const session = await auth.session(request); // AccountSession or null
```

Apply `sql/postgres.sql` or `sql/d1.sql` before serving requests. All expiry timestamps are milliseconds since the Unix epoch. Adapters parameterize values and use atomic SQL for consume, lock acquisition, and ownership-checked release. Schedule deletion of expired rows; expiry enforcement does not depend on cleanup. D1 callers must use the primary database binding (do not pass a read-replica session).

Custom stores must also implement `setMaximum(key: string, value: number, expiresAt: number): Promise<void>`. This operation atomically retains the greater numeric value and later expiry of the incoming and existing rows, including an existing expired row. It is used for monotonic subject-revocation timestamps. Values for these keys must be finite numeric strings. Implement it as one database operation; a read/compare/write sequence protected only by an expiring lease is insufficient. Both bundled SQL adapters use a single conditional upsert, with no schema change.

An optional trusted `fetchImpl: typeof fetch` replaces protocol transport for discovery, token exchange/refresh and both OIDC/logout JWKS verification. It defaults to the runtime fetch. Use it for platform service routing or signed test fixtures; never allow browser input to choose this implementation. Tests should authenticate through the same signed flow. No session-forging or encryption helpers are exported, and encrypted storage layout is private to the package version.

Explicit HTTP development cookies use `bcm-dev-${base64url(UTF8(clientId))}-session` and `bcm-dev-${base64url(UTF8(clientId))}-login-${state}` (unpadded base64url). This prevents distinct clients on different localhost ports from overwriting each other's cookies, since cookie scope does not include ports. For `test-game`, the session name is `bcm-dev-dGVzdC1nYW1l-session`. Production HTTPS names remain `__Host-bcm-session` and `__Host-bcm-login-${state}`. Register distinct development client IDs for games sharing one hostname.

`AUTH_ENCRYPTION_KEY` is exactly 32 cryptographically random bytes encoded as unpadded base64url (43 characters). Generate and keep it outside the source tree, and back it up with database recovery material. Changing it invalidates stored sessions. The client secret and encryption key must never be sent to browsers. All configuration must be present; callers should return an unavailable sign-in state when it is missing. `allowHttpLocalhost: true` permits HTTP only on localhost, 127.0.0.1, or ::1 for local integration tests. It uses distinctly named development cookies. Production uses host-prefixed Secure/HttpOnly/SameSite=Lax cookies without a Domain attribute.

The provider must expose same-origin HTTPS discovery, authorization, token, JWKS and end-session endpoints. Keycloak must issue RS256 ID tokens containing `sub`, `sid`, `auth_time`, `display_name`, and `email_verified: true`, and finite `expires_in`/`refresh_expires_in` in token responses. Set the shared display-name mapper to emit ID-token claims on refresh. Only the signed `realm_access.roles` entry `game-admin` grants an application role. Names are trimmed and limited to 1–60 characters. Render them as text. Identity is issuer-scoped: do not mix records from different realms into one application's user namespace.

## Routes and responses

| Route | Behavior |
| --- | --- |
| `GET /api/auth/login?next=/room/123` | 303 to authorization-code + PKCE sign-in; ten-minute, encrypted, browser-bound transaction. `next` must be a local path and cannot lead back to auth/login routes. |
| `GET /api/auth/login?mode=register` | Uses Keycloak's supported `prompt=create` registration request. |
| `GET /api/auth/login?popup=1&popup_id=...` | Binds window completion to the encrypted transaction. On completion, returns a CSP-protected page that signals the originating game and closes the sign-in window. The optional request identifier is 16–64 URL-safe characters. Cannot combine with silent sign-in. |
| `GET /api/auth/login?provider=google` | Uses the `google` broker hint. Enable only after configuring and testing that provider. |
| `GET /api/auth/login?silent=1` | One noninteractive SSO attempt. The caller must remember it attempted SSO and honor explicit guest choice. Do not retry automatically. Cannot combine with registration/provider. |
| `GET /api/auth/callback` | Consumes the transaction once, verifies state/browser binding/nonce/issuer/audience/signature, and returns 303 to `next`. Invalid callbacks return `/login?error=invalid_callback`. Provider denial returns `/login?error=access_denied&next=...`. A normal silent denial returns to `next` with `auth_error=login_required`; do not start another silent attempt from that flag. |
| `GET /api/auth/session` | `{ user: { id, displayName, roles } \| null, accountUrl }`. Never returns email, session reference, provider tokens, or central session ID. |
| `POST /api/auth/logout` | Requires an exact same-origin `Origin` header. Revokes local/central-sid records, clears the cookie and returns 303 to Keycloak end-session with `client_id` and an exact post-logout redirect. Keycloak may show logout confirmation. Use a native POST form, because fetch cannot perform this browser navigation. |
| `POST /api/auth/backchannel-logout` | Form-encoded `logout_token`; verifies RS256 signature, issuer, audience, five-minute age, jti replay, event type, and absence of nonce. `sid` takes precedence over `sub`; an event containing only `sub` revokes prior sessions for that subject. Returns 200 `{}`. Invalid/replayed events return generic 400; transient revocation failure returns 503 and allows retry. No browser Origin/cookie is required. |

Invalid query options return 400, wrong methods 405, foreign-origin logout 403, and unavailable authentication services 503. Auth responses use private/no-store and no-referrer. Do not log cookies, callback query strings, credentials, or raw protocol errors. Rate-limit auth routes at ingress.

## Sessions and multiplayer

Call `openAccountWindow` from `@blackcat/auth/browser` synchronously in a user click handler. Pass a safe local `next` path, optional `register: true`, `onSignedIn`, and `onError`. Retain its returned cleanup function and call it when cancelling or unmounting. On success, refresh the application's account state in place rather than navigating or remounting its game. The helper verifies `/api/auth/session` before reporting success; window messages contain no credentials or account details. It checks exact origin, source and request identity, with BroadcastChannel and session polling for providers that isolate the opener.

Blocked windows report an error without navigating the parent. Provide a retry control and an explicit same-tab sign-in link. Mobile browsers may open a new tab. Keep waiting/error controls keyboard-accessible and prevent their events from controlling the preserved game. Existing multiplayer seats need an explicit identity-transition policy: Tick keeps an active guest seat until leaving that room, while authenticated games reconcile their sockets with the verified session.

`session(request)` returns `{ user: { id, displayName, email, roles }, sid, expiresAt, reference }` or null. `reference` is a namespaced SHA-256 hash of the opaque cookie value. `sessionByReference(reference)` revalidates the same record without storing bearer cookies in Durable Object attachments or server socket state. Both methods fail closed. The reference is server-only, must never be accepted from a browser as authentication, and is excluded from public responses. Only persist a reference after a successful cookie-authenticated handshake. Independently enforce same-origin writes and WebSocket upgrades in each game.

Sessions refresh within 30 seconds of access expiry, with a maximum five-minute access window. Refresh uses a shared-store owner lock (30-second lease), five-second protocol request timeouts, bounded waiting, ownership checks, and revocation checks before and after persistence. Lost lock ownership fails closed. Provider session identity cannot change during refresh. Encrypted records expire no later than provider refresh expiry, the 24-hour idle limit, or seven days after central authentication. Expiry is checked again after awaited refresh/persistence operations and immediately before returning authentication. The browser cookie lasts only until the seven-day central maximum, allowing active server-side refresh to slide beyond the initial idle window. Retaining the opaque cookie never bypasses the shorter server-side idle or provider expiry.

Backchannel revocation markers survive seven days, including refreshes already in flight. Subject invalidation compares the signed logout event time against the session's central `auth_time`. Recheck authenticated sockets at least every five minutes and close affected sockets through `onLogout`; never trust client-supplied names, user IDs or roles. `onLogout` must be idempotent and fast. Different processes must fan invalidation out through their existing trusted game messaging layer.

## Validation and packaging

From repository root: `npm ci`, `npm test`, `npm run typecheck`, `npm run build`. Tests exercise a local HTTP OIDC fixture with real RSA keys, real PostgreSQL SQL through PGlite, and real SQLite SQL behind the D1 structural adapter. They do not establish live Keycloak, production PostgreSQL, Cloudflare D1, Google, or browser deployment acceptance.

Run `npm pack --workspace @blackcat/auth --pack-destination artifacts` after building. Copy `artifacts/blackcat-auth-0.1.1.tgz` to each game's `vendor/` and install that archive. Commit the archive with each game so Docker builds do not depend on a sibling checkout. The main and adapter entrypoints include TypeScript declarations and schema SQL.

Protocol API references: [oauth4webapi](https://github.com/panva/oauth4webapi/tree/main/docs), [Keycloak JavaScript adapter](https://www.keycloak.org/securing-apps/javascript-adapter).
