CREATE TABLE IF NOT EXISTS account_auth_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  expires_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS account_auth_state_expiry ON account_auth_state (expires_at);
-- Expiry is checked on every operation. Schedule this cleanup as maintenance:
-- DELETE FROM account_auth_state WHERE expires_at <= (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT;
